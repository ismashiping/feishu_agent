"""Plain text rendering, one bounded sending thread and official REST message API."""

import json
import logging
import re
from collections.abc import Callable
from dataclasses import dataclass
from math import isfinite
from queue import Empty, Queue
from threading import RLock, Thread
from time import monotonic
from typing import TYPE_CHECKING, Annotated, Literal, Protocol, get_args
from urllib.parse import urlsplit

from pydantic import Field, StrictInt

from clinical_agent.channels.feishu.dedup import Lease, OperationResult
from clinical_agent.channels.feishu.events import MessageEnvelope
from clinical_agent.channels.feishu.worker import Delivery
from clinical_agent.domain.citations import (
    BASE_LIMITATIONS,
    OPENALEX_FULLTEXT_LIMITATION,
    OPENALEX_NO_FULLTEXT_LIMITATION,
)
from clinical_agent.domain.models import DTO
from clinical_agent.domain.openalex import OpenAlexProvenance
from clinical_agent.domain.report import ResearchReport, render_report
from clinical_agent.domain.research import ResearchAnswer

if TYPE_CHECKING:
    import httpx

MAX_CONTENT_BYTES = 24000
MAX_BODY_BYTES = 30000
NOTICE = {
    "research_failed": "研究处理失败，请稍后再试。",
    "busy": "当前任务较多，请稍后再试。",
    "unavailable": "服务暂不可用，请稍后再试。",
    "invalid_input": "暂无法处理此输入，请发送有效文本问题。",
}
TOO_LONG = "结果过长，未展示结论及引用。请缩小问题范围后重试；本次仅检索本地文献。"
DISCLAIMER = (
    "仅检索本地已导入文献，不保证覆盖最新或全部研究；用于科研辅助，不用于个体诊断或治疗决策。"
)
NoticeCode = Literal["research_failed", "busy", "unavailable", "invalid_input"]
SendStatus = Literal["sent", "failed", "unknown", "timed_out", "lost", "unavailable"]
Guard = Callable[[], SendStatus | None]
_LOG = logging.getLogger('feishu.sender')


def text_content(text: str) -> str:
    return json.dumps({"text": text}, ensure_ascii=False, separators=(",", ":"))


def _work_reason(work) -> str:
    text = _fulltext_reason(work.reason)
    detail = getattr(work, "detail", None)
    if isinstance(detail, str) and detail and re.fullmatch(r"[a-z0-9_.:-]{1,80}", detail):
        return f"{text}；依据：{detail}"
    return text


def _fulltext_reason(reason: str) -> str:
    return {
        "fulltext_no_fulltext_url": "OpenAlex 没有提供全文地址",
        "fulltext_license_not_allowed": "获取全文失败",
        "fulltext_license_restricted": "获取全文失败",
        "fulltext_license_unknown": "获取全文失败",
        "fulltext_official_content_unavailable": "OpenAlex 没有提供全文地址",
        "fulltext_no_downloadable_file": "OpenAlex 没有提供全文地址",
        "fulltext_no_oa_location": "OpenAlex 没有提供全文地址",
        "fulltext_identity_mismatch": "文件与论文身份不一致",
        "fulltext_download_failed": "下载失败",
        "fulltext_http_failed": "下载失败",
        "fulltext_auth_failed": "访问被拒绝，未绕过付费墙或登录限制",
        "fulltext_unsafe_url": "链接未通过安全校验",
        "fulltext_url_not_allowed": "链接未通过安全校验",
        "fulltext_budget": "超出本次获取预算",
        "fulltext_timeout": "获取超时",
        "fulltext_invalid_file": "下载内容不是有效的 PDF 或 XML",
        "fulltext_not_pdf": "下载内容不是有效的 PDF 或 XML",
        "fulltext_parse_failed": "正文解析失败或质量不足",
        "fulltext_embedding_failed": "向量化失败",
        "fulltext_location_unsupported": "没有受支持的全文入口",
        "fulltext_empty": "未解析出正文",
        "fulltext_failed": "获取失败",
    }.get(reason, reason)


def _plain(text: str) -> str:
    # Text messages still interpret at tags. Keep untrusted prose as visible text.
    table: dict[str, str | int | None] = {"<": "＜", ">": "＞", "&": "＆"}
    return text.translate(str.maketrans(table))


def _safe_url(value: str | None) -> str | None:
    if not value:
        return None
    try:
        url = urlsplit(value)
        if (
            url.scheme in {"http", "https"}
            and url.hostname
            and not (url.username or url.password or any(c.isspace() for c in value))
        ):
            return value
    except ValueError:
        pass
    return None


def _readable_answer_lines(answer: ResearchAnswer) -> list[str]:
    openalex = isinstance(answer.search_provenance, OpenAlexProvenance)
    online_source = (
        "OpenAlex" if isinstance(answer.search_provenance, OpenAlexProvenance) else "PubMed"
    )
    numbers = {
        evidence.chunk_id: number
        for number, source in enumerate(answer.sources, 1)
        for evidence in source.evidence
    }
    lines: list[str] = []
    if answer.status == "needs_clarification":
        lines.append("本次尚未执行检索；需澄清以下信息：")
        if answer.query_plan:
            question = answer.query_plan.structured_question
            lines.extend(
                _plain(item) for item in question.blocking_ambiguities or question.ambiguities
            )
    elif answer.status == "insufficient_evidence":
        if answer.unobtained_works:
            lines.append("已发现相关论文，但没有获得可用全文，不能依据摘要生成科研结论。")
        else:
            lines.append("本次检索证据不足，不代表不存在相关研究或证据证明无效。")
    caveats: dict[str, list[int]] = {}
    section = None
    for claim in answer.claims:
        if claim.section and claim.section != section:
            lines.append(_plain(claim.section))
            section = claim.section
        refs = " ".join(
            f"[{n}]" for n in dict.fromkeys(numbers[k] for k in claim.evidence_chunk_ids)
        )
        label = {"evidence": "", "inference": "推断：", "uncertainty": "不确定："}[claim.kind]
        lines.append(f"{label}{_plain(claim.text)} {refs}".rstrip())
        for item in claim.limitations:
            linked = caveats.setdefault(item, [])
            linked.extend(numbers[k] for k in claim.evidence_chunk_ids if numbers[k] not in linked)
        lines.append("")
    if answer.sources:
        lines.append("参考文献")
    scopes = {
        "abstract": "摘要（未阅读全文）",
        "extracted_text": "PDF文本层（完整性未验证）",
        "full_text": "全文来源",
    }
    for number, source in enumerate(answer.sources, 1):
        date = str(source.publication_date.year or source.publication_date.raw or "年份未知")
        lines.append(f"[{number}] {_plain(source.title)}（{_plain(date)}）")
        metadata = []
        if source.pmid:
            metadata.append(f"PMID：{source.pmid}")
        if source.doi:
            metadata.append(f"DOI：{_plain(source.doi)}")
        if metadata:
            lines.append("；".join(metadata))
        if openalex and source.doi:
            doi_url = _safe_url("https://doi.org/" + source.doi)
            if doi_url:
                lines.append(doi_url)
        url = _safe_url(source.source_url)
        if url:
            lines.append(_plain(url))
        if source.source_notices:
            lines.append("来源关联标记：" + _plain("、".join(source.source_notices)))
        for evidence in source.evidence:
            for passage in evidence.fulltext:
                lines.append(
                    f"全文证据：{_plain(passage.section)}；"
                    + ("" if openalex else f"字符 [{passage.start},{passage.end})；")
                    + f"{_plain(passage.pmcid or passage.openalex_id or '来源未知')}"
                    + (f"；第{passage.page}页" if passage.page else "")
                )
        if source.content_scope != "abstract":
            for evidence in source.evidence:
                loc = evidence.location
                page = f"第{loc.page}页；" if loc.page else ""
                section = f"{_plain(loc.section)}；" if loc.section else ""
                lines.append(f"定位：{page}{section}字符 [{loc.start},{loc.end})")
    for scope, label in scopes.items():
        refs = " ".join(
            f"[{n}]"
            for n, source in enumerate(answer.sources, 1)
            if source.content_scope == scope
            and not any(e.location.kind == "fulltext" for e in source.evidence)
        )
        if refs:
            lines.append(f"证据范围：{label} {refs}")
    fulltext_refs = " ".join(
        f"[{n}]"
        for n, source in enumerate(answer.sources, 1)
        if any(e.location.kind == "fulltext" for e in source.evidence)
    )
    if fulltext_refs:
        lines.append(f"证据范围：已获取并引用的全文段落 {fulltext_refs}")
    if answer.unobtained_works:
        lines.append("发现但未获得全文（不是结论证据）")
        for work in answer.unobtained_works:
            year = str(work.year or "年份未知")
            doi = f"；DOI：{_plain(work.doi)}" if work.doi else ""
            lines.append(f"{_plain(work.title)}（{year}）{doi}；原因：{_plain(_work_reason(work))}")
    # Only exact, known system notices are consolidated; never fuzzy-match medical caveats.
    covered = {
        BASE_LIMITATIONS[0],
        BASE_LIMITATIONS[2],
        "部分来源仅包含摘要，不能视为已阅读全文。",
        "部分来源为PDF文本层提取，未验证版面、表格或全文完整性。",
    }
    if openalex:
        covered.update(
            {
                BASE_LIMITATIONS[1],
                "已查询 OpenAlex，证据限于本次检索与已获取摘要，不保证检全。",
                "已查询 OpenAlex，未发现可进入回答的论文，不保证检全。",
                OPENALEX_FULLTEXT_LIMITATION,
                OPENALEX_NO_FULLTEXT_LIMITATION,
                "已查询 OpenAlex；证据限于实际引用的摘要或全文段落，不保证检全。",
                "本次部分检索或筛选未完成，证据范围有限。",
                "证据尚未充分覆盖：" + "、".join(answer.search_provenance.evidence_gaps),
            }
        )
    if answer.retrieval_scope != "local":
        online_scope = (
            "已按记录查询 PubMed；结果有查询、日期、数量和摘要范围限制，"
            "不保证检全或覆盖全部最新研究。"
        )
        covered.update(
            {online_scope, online_scope + " PubMed候选已截断，本次未发现不能解释为不存在相关研究。"}
        )
    for item in answer.limitations:
        if item not in covered:
            caveats.setdefault(item, [])
    if caveats:
        lines.extend(["", "局限与范围"])
        for item, linked_numbers in caveats.items():
            text = (
                "引用关联已核对；医学语义支持仍需人工复核。"
                if item == BASE_LIMITATIONS[1]
                else _plain(item)
            )
            lines.append(
                text + (" " + " ".join(f"[{n}]" for n in linked_numbers) if linked_numbers else "")
            )
    if answer.status != "needs_clarification":
        search = answer.search_provenance
        if search and not openalex:
            lines.append(
                f"检索范围：{online_source} 匹配 {search.total_count} 条；"
                f"本次返回 {search.returned_count} 个候选；请求状态：{search.status}。"
                + (
                    "候选已截断，不代表全部相关研究。"
                    if search.truncated
                    else "候选未截断，但不保证检全。"
                )
            )
        if openalex and search.status == "partial":
            lines.append("本次检索未完整完成，结论仅限所列文献，不代表领域全貌。")
        lines.append(
            "未执行在线 PubMed 检索。" + DISCLAIMER
            if answer.retrieval_scope == "local"
            else f"本次使用在线 {online_source}"
            + "；仅用于科研辅助，不保证检全，不用于个体诊断或治疗决策。"
        )
    return lines


def render_answer(answer: ResearchAnswer, *, include_audit: bool = False) -> str:
    """Keep complete claims/citations or replace the entire result; never slice evidence."""
    answer = ResearchAnswer.model_validate(answer)
    online_source = (
        "OpenAlex" if isinstance(answer.search_provenance, OpenAlexProvenance) else "PubMed"
    )
    lines = (
        [DISCLAIMER]
        if answer.retrieval_scope == "local"
        else [
            f"本次使用在线 {online_source}"
            + "；仅用于科研辅助，不保证检全，不用于个体诊断或治疗决策。"
        ]
    )
    if answer.status == "needs_clarification":
        lines = ["本次尚未执行检索；需先确认关键研究主题或约束。"]
    elif answer.retrieval_scope == "local":
        lines.append("来源范围：local（仅本地；未执行在线 PubMed 检索）。")
    if answer.retrieval_scope != "online":
        lines.append(
            f"本地检索：{answer.local_retrieval_mode}；策略：{answer.local_retrieval_strategy}"
        )
    if answer.search_provenance is not None:
        search = answer.search_provenance
        lines.append(
            f"检索：{_plain(search.query_sent)}；时间：{search.fetched_at.isoformat()}；"
            f"状态：{search.status}；返回 {search.returned_count}/{search.total_count}；"
            f"截断：{search.truncated}"
        )
    numbers = {
        evidence.chunk_id: number
        for number, source in enumerate(answer.sources, 1)
        for evidence in source.evidence
    }
    kinds = {"evidence": "证据", "inference": "推断", "uncertainty": "不确定"}
    scopes = {
        "abstract": "摘要（未阅读全文）",
        "extracted_text": "PDF文本层（完整性未验证）",
        "full_text": "全文来源",
    }
    if answer.query_plan is not None:
        structured = answer.query_plan.structured_question
        lines.append(f"问题分类：{structured.question_type}")
        if answer.status == "needs_clarification":
            lines.append("需澄清：请补充以下信息后重新提问。")
        for label, pico_value in [
            ("P 人群", structured.pico.population),
            ("I 干预/检测", structured.pico.intervention),
            ("C 对照", structured.pico.comparison),
            ("O 结局", structured.pico.outcome),
        ]:
            lines.append(f"{label}：{_plain(pico_value.text) if pico_value else '未提供'}")
        for term in answer.query_plan.terms:
            if term.origin == "query_expansion":
                lines.append(f"候选检索扩展：{_plain(term.text)}")
        questions = structured.blocking_ambiguities or structured.ambiguities
        label = "需澄清" if answer.status == "needs_clarification" else "可选细化"
        lines.extend(f"{label}：{_plain(item)}" for item in questions[:2])
    if answer.status == "insufficient_evidence":
        if answer.unobtained_works:
            lines.append("证据不足：已发现相关论文，但没有获得可用全文，不能依据摘要生成结论。")
        else:
            lines.append("证据不足：未检索到符合条件的证据，不代表证据证明无效。")
    if answer.unobtained_works:
        lines.append("发现但未获得全文（不是结论证据）")
        for work in answer.unobtained_works:
            lines.append(f"{_plain(work.title)}；原因：{_plain(_work_reason(work))}")
    for claim in answer.claims:
        refs = " ".join(f"[{numbers[key]}] chunk={key}" for key in claim.evidence_chunk_ids)
        lines.append(f"{claim.claim_id} {kinds[claim.kind]}：{_plain(claim.text)}\n来源：{refs}")
        lines.extend(f"结论局限：{_plain(item)}" for item in claim.limitations)
    for number, source in enumerate(answer.sources, 1):
        date = source.publication_date
        date_text = date.raw or "未知"
        lines.append(f"[{number}] {_plain(source.title)}")
        lines.append(
            f"作者：{_plain('、'.join(source.authors)) or '未知'}；日期：{_plain(date_text)}；"
            f"期刊：{_plain(source.journal or '未知')}"
        )
        lines.append(
            f"document={source.document_id}；hash={source.content_hash}；"
            f"范围：{scopes[source.content_scope]}"
        )
        for label, value in [
            ("PMID", source.pmid),
            ("DOI", source.doi),
            ("URL", _safe_url(source.source_url)),
        ]:
            if value:
                lines.append(f"{label}：{_plain(value)}")
        if source.publication_types:
            lines.append("出版类型：" + _plain("、".join(source.publication_types)))
        if source.source_notices:
            lines.append("来源关联标记：" + _plain("、".join(source.source_notices)))
        for evidence in source.evidence:
            loc = evidence.location
            position = f"第{loc.page}页" if loc.kind == "pdf_page" else "摘要"
            section = f" {_plain(loc.section)}" if loc.section else ""
            lines.append(f"chunk={evidence.chunk_id} {position}{section} [{loc.start},{loc.end})")
    lines.extend(f"局限：{_plain(item)}" for item in answer.limitations)
    text = "\n".join(lines if include_audit else _readable_answer_lines(answer))
    content = text_content(text)
    # content is itself a JSON string in the outer request. Quotes/backslashes
    # expand twice; reserve the maximum validated chat ID for the create route.
    body = json.dumps(
        {"msg_type": "text", "content": content, "receive_id": "x" * 256},
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode("utf-8")
    return (
        text
        if len(content.encode("utf-8")) <= MAX_CONTENT_BYTES and len(body) <= MAX_BODY_BYTES
        else (
            TOO_LONG
            if answer.retrieval_scope == "local"
            else f"结果过长，未展示结论及引用。请缩小范围后重试；本次已按记录查询 {online_source}。"
        )
    )


def split_report_text(text: str) -> list[str]:
    """Preserve every character, escape Feishu mentions, bound all parts before sending."""
    text = _plain(text)
    # 2000 codepoints bounds worst-case 4-byte Unicode and JSON escaping twice.
    parts = [text[i : i + 2000] for i in range(0, len(text), 2000)] or [""]
    if len(parts) > 32:
        raise ValueError("Report exceeds bounded message count; use CLI/API export")
    return [f"科研调研报告（{i}/{len(parts)}）\n{part}" for i, part in enumerate(parts, 1)]


class SenderPolicy(DTO):
    capacity: Annotated[StrictInt, Field(ge=1, le=64)] = 8
    send_ms: Annotated[StrictInt, Field(ge=1, le=10000)] = 5000
    notice_ms: Annotated[StrictInt, Field(ge=1, le=15000)] = 5000


class SendingDedupPort(Protocol):
    def check(self, lease: Lease) -> OperationResult: ...
    def complete(self, lease: Lease) -> OperationResult: ...
    def release(self, lease: Lease) -> OperationResult: ...


class MessageTransport(Protocol):
    """Call guard immediately before side effects, obey deadline, never retry."""

    def send(
        self, envelope: MessageEnvelope, text: str, *, deadline: float, guard: Guard
    ) -> SendStatus: ...


class OfficialMessageAPI:
    """Borrows a nonretrying HTTP client and a deadline-aware token provider.

    Construct the client explicitly with HTTPTransport(retries=0), redirects disabled,
    no event hooks that log secrets, and no inherited credentials/default parameters.
    """

    def __init__(
        self,
        client: "httpx.Client",
        *,
        token: Callable[[float], str],
        clock: Callable[[], float] = monotonic,
    ) -> None:
        self._client, self._token, self._clock = client, token, clock

    def send(
        self, envelope: MessageEnvelope, text: str, *, deadline: float, guard: Guard
    ) -> SendStatus:
        # No message call has started in this stage: failure is definitely unsent.
        if self._clock() >= deadline:
            return "timed_out"
        try:
            token = self._token(deadline)
            if not isinstance(token, str) or not token.strip() or any(c.isspace() for c in token):
                return "failed"
            content = text_content(text)
            if len(content.encode("utf-8")) > MAX_CONTENT_BYTES:
                return "failed"
            body = {"msg_type": "text", "content": content}
            path, params = "/im/v1/messages", {}
            if envelope.message_id:
                path += f"/{envelope.message_id}/reply"
            else:
                body["receive_id"] = envelope.chat_id
                params["receive_id_type"] = "chat_id"
            payload = json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            if len(payload) > MAX_BODY_BYTES:
                return "failed"
            stopped = guard()
            if stopped:
                return stopped
            remaining = deadline - self._clock()
            if remaining <= 0:
                return "timed_out"
        except Exception:
            return "failed"
        try:
            response = self._client.post(
                "https://open.feishu.cn/open-apis" + path,
                params=params,
                content=payload,
                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                timeout=remaining,
                follow_redirects=False,
            )
            if 400 <= response.status_code < 500:
                return "failed"
            if not 200 <= response.status_code < 300:
                return "unknown"
            result = response.json()
            if not isinstance(result, dict) or type(result.get("code")) is not int:
                return "unknown"
            if result["code"] != 0:
                return "failed"
            data = result.get("data")
            if (
                isinstance(data, dict)
                and isinstance(data.get("message_id"), str)
                and data["message_id"].strip()
            ):
                return "sent"
        except Exception:
            # An exception after starting HTTP cannot prove absence of a side effect.
            pass
        return "unknown"


@dataclass(frozen=True)
class _Item:
    envelope: MessageEnvelope
    deadline: float
    lease: Lease | None = None
    answer: ResearchAnswer | ResearchReport | None = None
    code: NoticeCode | None = None


class Sender:
    """offer transfers leases only on True; close never closes borrowed clients."""

    def __init__(
        self,
        *,
        dedup: SendingDedupPort,
        transport: MessageTransport,
        policy: SenderPolicy | None = None,
        clock: Callable[[], float] = monotonic,
    ) -> None:
        self.policy = SenderPolicy.model_validate(policy if policy is not None else SenderPolicy())
        self._dedup, self._transport, self._clock = dedup, transport, clock
        self._queue: Queue[_Item] = Queue(maxsize=self.policy.capacity)
        self._lock = RLock()
        self._pending = 0
        self._closing = False
        self._thread = Thread(target=self._run, name="clinical-feishu-sender")
        self._thread.start()

    def _offer(self, item: _Item) -> bool:
        with self._lock:
            if self._closing or self._pending >= self.policy.capacity:
                return False
            self._queue.put_nowait(item)
            self._pending += 1
            return True

    def offer(self, delivery: Delivery) -> bool:
        try:
            envelope = MessageEnvelope.model_validate(delivery.envelope).model_copy(deep=True)
            lease = Lease.model_validate(delivery.lease).model_copy(deep=True)
            deadline = delivery.deadline
            if (
                isinstance(deadline, bool)
                or not isinstance(deadline, (int, float))
                or not isfinite(deadline)
            ):
                raise ValueError
            if lease.identity != envelope.dedup_identity:
                raise ValueError
            if (delivery.answer is None) == (delivery.error_code is None):
                raise ValueError
            answer = None
            if delivery.answer is not None:
                answer = (
                    ResearchReport.model_validate(delivery.answer)
                    if isinstance(delivery.answer, ResearchReport)
                    else ResearchAnswer.model_validate(delivery.answer)
                ).model_copy(deep=True)
                if answer.request_id != envelope.request_id:
                    raise ValueError
            elif delivery.error_code != "research_failed":
                raise ValueError
            item = _Item(envelope, deadline, lease, answer, delivery.error_code)
        except Exception:
            raise ValueError("Invalid delivery") from None
        return self._offer(item)

    def offer_notice(self, envelope: MessageEnvelope, code: NoticeCode) -> bool:
        if code not in NOTICE:
            raise ValueError("Invalid notice")
        envelope = MessageEnvelope.model_validate(envelope).model_copy(deep=True)
        return self._offer(_Item(envelope, self._clock() + self.policy.notice_ms / 1000, code=code))

    def _guard(self, item: _Item) -> SendStatus | None:
        if self._clock() >= item.deadline:
            return "timed_out"
        if item.lease is not None:
            try:
                state = self._dedup.check(item.lease)
            except Exception:
                return "unavailable"
            if state != "owned":
                return "lost" if state == "lost" else "unavailable"
        return "timed_out" if self._clock() >= item.deadline else None

    def _process(self, item: _Item) -> None:
        status = self._guard(item)
        if status is None:
            try:
                text = (
                    (
                        render_report(item.answer)
                        if isinstance(item.answer, ResearchReport)
                        else render_answer(item.answer)
                    )
                    if item.answer is not None
                    else NOTICE[item.code or "research_failed"]
                )
            except Exception:
                text = NOTICE["research_failed"]
            status = self._guard(item)
            if status is None:
                try:
                    try:
                        parts = (
                            split_report_text(text)
                            if isinstance(item.answer, ResearchReport)
                            else [text]
                        )
                    except ValueError:
                        parts = [
                            "报告过长，未发送任何报告内容或引用。"
                            "请缩小检索范围，或使用 CLI/API 获取完整报告。"
                        ]
                    for index, part in enumerate(parts):
                        status = (
                            self._guard(item) if isinstance(item.answer, ResearchReport) else None
                        )
                        if status is None:
                            status = self._transport.send(
                                item.envelope,
                                part,
                                deadline=min(
                                    item.deadline, self._clock() + self.policy.send_ms / 1000
                                ),
                                guard=lambda: self._guard(item),
                            )
                        if status != "sent":
                            if index:
                                status = "unknown"
                            break
                    if status not in get_args(SendStatus):
                        status = "unknown"
                except Exception:
                    status = "unknown"
        cleanup = "untouched"
        if item.lease is not None and status in {"sent", "failed", "timed_out"}:
            try:
                operation = self._dedup.complete if status == "sent" else self._dedup.release
                cleanup = operation(item.lease)
                if cleanup not in {"owned", "lost", "unavailable"}:
                    cleanup = "unavailable"
            except Exception:
                cleanup = "unavailable"
        _LOG.info(
            "feishu_delivery",
            extra={
                "request_id": str(item.envelope.request_id),
                "status": status,
                "dedup_status": cleanup,
            },
        )

    def _run(self) -> None:
        while True:
            try:
                item = self._queue.get(timeout=0.05)
            except Empty:
                with self._lock:
                    if self._closing and not self._pending:
                        return
                continue
            try:
                self._process(item)
            finally:
                with self._lock:
                    self._pending -= 1
                self._queue.task_done()

    def close(self, *, timeout_seconds: float = 5.0) -> bool:
        if (
            isinstance(timeout_seconds, bool)
            or not isinstance(timeout_seconds, (int, float))
            or not isfinite(timeout_seconds)
            or timeout_seconds < 0
        ):
            raise ValueError("Invalid shutdown timeout")
        with self._lock:
            self._closing = True
        self._thread.join(timeout_seconds)
        return not self._thread.is_alive()
