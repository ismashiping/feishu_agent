"""External messaging channel implementations."""
